"""
Audio Visualizer Pro - Modulares Audio-Visualisierungs-System
"""

__version__ = "2.0.0"
