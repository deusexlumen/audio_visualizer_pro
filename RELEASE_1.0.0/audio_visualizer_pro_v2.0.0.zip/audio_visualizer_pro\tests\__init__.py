"""
Tests für Audio Visualizer Pro
"""
